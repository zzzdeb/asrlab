#!/bin/sh

../rasr/src/Tools/SpeechRecognizer/speech-recognizer.linux-x86_64-standard \
    --config=config/recognition-triphones-lda-pruned.config
